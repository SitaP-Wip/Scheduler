﻿using System;
using System.Diagnostics;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.Identity.Web;
using Microsoft.Graph;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using UBS.POC.SmartScheduler.Models;
using System.IO;
using System.Collections.Generic;

namespace UBS.POC.SmartScheduler.Controllers
{
    [Authorize]
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        private readonly GraphServiceClient _graphServiceClient;

        public HomeController(ILogger<HomeController> logger,
                          GraphServiceClient graphServiceClient)
        {
            _logger = logger;
            _graphServiceClient = graphServiceClient;
        }

        [AuthorizeForScopes(ScopeKeySection = "DownstreamApi:Scopes")]
        public async Task<IActionResult> Index()
        {
            var user = await _graphServiceClient.Me.Request().GetAsync();
            ViewData["ApiResult"] = user.DisplayName;

            return View();
        }

        [AuthorizeForScopes(ScopeKeySection = "DownstreamApi:Scopes")]
        public async Task<IActionResult> Profile()
        {
            var me = await _graphServiceClient.Me.Request().GetAsync();
            ViewData["Me"] = me;

            try
            {
                // Get user photo
                using (var photoStream = await _graphServiceClient.Me.Photo.Content.Request().GetAsync())
                {
                    byte[] photoByte = ((MemoryStream)photoStream).ToArray();
                    ViewData["Photo"] = Convert.ToBase64String(photoByte);
                }
            }
            catch (System.Exception)
            {
                ViewData["Photo"] = null;
            }

            return View();
        }
        [AuthorizeForScopes(ScopeKeySection = "DownstreamApi:Scopes")]
        public async Task<IActionResult> Manager()
        {
            var me = await _graphServiceClient.Me.Manager.Request().GetAsync();
            ViewData["Me"] = me;

            try
            {
                // Get user photo
                //using (var photoStream = await _graphServiceClient.Me.Manager.Photo.Content.Request().GetAsync())
                //{
                //    byte[] photoByte = ((MemoryStream)photoStream).ToArray();
                //    ViewData["Photo"] = Convert.ToBase64String(photoByte);
                //}
            }
            catch (System.Exception)
            {
                ViewData["Photo"] = null;
            }

            return View();
        }
        [AuthorizeForScopes(ScopeKeySection = "DownstreamApi:Scopes")]
        public async Task<IActionResult> Publish()
        {
            var me = await _graphServiceClient.Me.Manager.Request().GetAsync();
            ViewData["Me"] = me;

            return View();
        }

        [AuthorizeForScopes(ScopeKeySection = "DownstreamApi:Scopes")]
        public async Task<IActionResult> Consume()
        {
            var me = await _graphServiceClient.Me.Manager.Request().GetAsync();
            ViewData["Me"] = me;

            ViewData["Calendars"] = null;

            return View();
        }
        [AuthorizeForScopes(ScopeKeySection = "DownstreamApi:Scopes")]
        [HttpPost]
        public async Task<IActionResult> SearchUserCalendar(string SelectedUser, string txtStartDate, string txtEndDate)
        {
            var calendars = await _graphServiceClient.Me.Calendars
                            .Request().GetAsync();

            string CalendarID = "";
            foreach (var c in calendars)
            {
                if (c.Name == "Calendar" &&
                    c.Owner.Address == SelectedUser)
                {
                    CalendarID = c.Id;
                    break;
                }
            }

            ViewData["UserName"] = SelectedUser;
            ViewData["TimePeriod"] = "From " + txtStartDate + " to " + txtEndDate;

            if (string.IsNullOrEmpty(CalendarID))
            {
                ViewData["Calendars"] = "0";
            }
            else
            {
                var queryOptions = new List<QueryOption>()
{
    new QueryOption("startDateTime", txtStartDate),
    new QueryOption("endDateTime", txtEndDate)
};

                var UserCalendarView = await _graphServiceClient.Me.Calendars[CalendarID]
                    .CalendarView
                    .Request(queryOptions)
                    //.Expand("SingleValueExtendedProperties($filter=Id eq 'String {e25517a4-e24b-458f-873a-300c62ad31d6} Name CustomProperty')")
                    //.Expand("singleValueExtendedProperties($filter=id%20eq%20'String%20%7Be25517a4-e24b-458f-873a-300c62ad31d6%7D%CustomProperty')")
                    .Expand("singleValueExtendedProperties($filter=id eq 'String {e25517a4-e24b-458f-873a-300c62ad31d6} Name CustomProperty')")
                    .Header("Prefer", "outlook.timezone=\"India Standard Time\"")
                    .GetAsync();

                ViewData["Calendars"] = UserCalendarView;
            }

            return View();
        }
        [AuthorizeForScopes(ScopeKeySection = "DownstreamApi:Scopes")]
        [HttpPost]
        public async Task<IActionResult> PublishCalendar(string txtStartDate, string txtEndDate, string txtStartTime, string txtEndTime)
        {
            DateTime dtStartDate = Convert.ToDateTime(txtStartDate);
            DateTime dtEndDate = Convert.ToDateTime(txtEndDate);

            while (dtStartDate <= dtEndDate)
            {
                if (dtStartDate.DayOfWeek == System.DayOfWeek.Sunday || dtStartDate.DayOfWeek == System.DayOfWeek.Saturday)
                {
                    dtStartDate = dtStartDate.AddDays(1);
                    continue;
                }

                SingleValueLegacyExtendedProperty singleEP1 = new SingleValueLegacyExtendedProperty
                {
                    Id = "String {e25517a4-e24b-458f-873a-300c62ad31d6} Name CustomProperty",
                    Value = "Created using Smart Scheduler"
                };

                var newEvent = new Event()
                {
                    Subject = "Just a Sample Invite from Code. Please Ignore.",
                    Body = new ItemBody
                    {
                        ContentType = BodyType.Html,
                        Content = "This appointment is created using Smart Scheduler Application for Publishing availability to Clients. Please do not make any changes."
                    },
                    Start = new DateTimeTimeZone
                    {
                        DateTime = dtStartDate.ToString("yyyy-MM-dd") + "T" + txtStartTime,
                        TimeZone = "India Standard Time"
                    },
                    End = new DateTimeTimeZone
                    {
                        DateTime = dtStartDate.ToString("yyyy-MM-dd") + "T" + txtEndTime,
                        TimeZone = "India Standard Time"
                    },
                    ShowAs = FreeBusyStatus.Free,
                    Categories = new string[] { "Publish Calendar" },
                    TransactionId = Guid.NewGuid().ToString(),

                    SingleValueExtendedProperties = new EventSingleValueExtendedPropertiesCollectionPage()
                    { singleEP1 }
                };

                await _graphServiceClient.Me.Calendar
                    .Events
                    .Request()
                    .AddAsync(newEvent);

                dtStartDate = dtStartDate.AddDays(1);
            }

            return RedirectToAction("Index", "Home");
        }
        [AuthorizeForScopes(ScopeKeySection = "DownstreamApi:Scopes")]
        public async Task<IActionResult> Calendar()
        {
            var me = await _graphServiceClient.Me.Events.Request()
                    .Select("subject,body,bodyPreview,organizer,attendees,start,end,location")
                    .GetAsync();

            ViewData["Me"] = me;

            return View();
        }
        public IActionResult Privacy()
        {
            return View();
        }

        [AllowAnonymous]
        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}